//
//  main.m
//  createAuth
//
//  Created by 廖 廖智 on 16/4/3.
//  Copyright © 2016年 廖 廖智. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+AES128.h"
#import "NSString+MD5andSHA1.h"
#import "RSAEncryptor.h"

//AES为ECB模式，密钥长度为128，补码方式为PKCS7Padding  加密结果为十六进制
//RSA密钥长度为1024
int main(int argc, const char * argv[]) {
    @autoreleasepool {
    //自己调试
        
        
    }
    return 0;
}
