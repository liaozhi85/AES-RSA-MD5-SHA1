//
//  NSData+AES256.h
//  createAuth
//
//  Created by 廖 廖智 on 16/4/3.
//  Copyright © 2016年 廖 廖智. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (AES128)
-(NSData *) aes128_encrypt:(NSString *)key;
-(NSData *) aes128_decrypt:(NSString *)key;
@end
