//
//  NSString+MD5andSHA1.h
//  createAuth
//
//  Created by 廖 廖智 on 16/4/3.
//  Copyright © 2016年 廖 廖智. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5andSHA1)
- (NSString *)md5;
- (NSString *)sha1;
@end
