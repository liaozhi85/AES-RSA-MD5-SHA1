//
//  NSString+AES256.h
//  createAuth
//
//  Created by 廖 廖智 on 16/4/3.
//  Copyright © 2016年 廖 廖智. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (AES128)
-(NSString *) aes128_encrypt:(NSString *)key;
-(NSString *) aes128_decrypt:(NSString *)key;
@end
